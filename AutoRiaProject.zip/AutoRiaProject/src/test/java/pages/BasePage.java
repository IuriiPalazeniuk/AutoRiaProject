package pages;

import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;


import static com.codeborne.selenide.Selectors.byXpath;


public class BasePage extends Selenide {

    private String brand = "brandTooltipBrandAutocompleteInput-brand";

    public void selectCar(String car, String parameters) {
        $(byXpath("(//label[@for='brandTooltipBrandAutocompleteInput-" + car + "'])[2]")).click();
        $(byXpath(" //a[@class='item bold' and contains(text(), '" + parameters + "')]")).click();
    }

    public void clickButton(String name) {
        $(byXpath("//button[@type='" + name + "']")).click();
    }

    public void switchToFrame(WebElement element) {
        switchTo();
    }
}
