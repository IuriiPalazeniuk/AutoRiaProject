package pages;

import com.codeborne.selenide.SelenideElement;

import static com.codeborne.selenide.Selectors.byId;

public class SearchResultPage extends BasePage {

    private String header = "headerPage";


    public SelenideElement getHeader() {
        return $(byId(header));
    }
}
