package pages;
import static com.codeborne.selenide.Selectors.*;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

@Getter
public class LoginPage extends BasePage {

    private String mail = "10rubliv@gmail.com";
    private String password = "Yura19861116";

    @FindBy(xpath = "(//a[@href='/mymenu/'])[1]")
    private SelenideElement logedUser;

    @FindBy(xpath = "//a[@class='item fb-social']")
    private SelenideElement logInByFaceBook;

    @FindBy(id = "email")
    private SelenideElement mailFacebook;

    @FindBy(id = "pass")
    private SelenideElement passFacebook;

    @FindBy(xpath = "//iframe[@id='login_frame']")
    private WebElement loginFrame;


    public void loginBySocial() {
        loginFrame.isDisplayed();
        switchTo().frame(loginFrame);
        $(byXpath("//a[@class='item fb-social']")).waitUntil(Condition.enabled, 5000).click();
        switchTo().window(2);
        $(byId("email")).setValue(mail);
        $(byId("pass")).setValue(password);
        clickButton("submit");
    }

}
