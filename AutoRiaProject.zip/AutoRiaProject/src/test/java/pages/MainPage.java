package pages;

import static com.codeborne.selenide.Selectors.*;

public class MainPage extends BasePage {

    private String logIn = "tl";


    public void searchCar(String marka_auto, String model1) {
        selectCar("brand", marka_auto);
        selectCar("model", model1);
    }

    public LoginPage clickLogIn() {
        $(byClassName(logIn)).click();
        return page(LoginPage.class);
    }
}
